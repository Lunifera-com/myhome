package com.lunifera.myhome.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by bernhardedler on 08.12.15.
 */
public abstract class Endpoint implements Parcelable{

    @SerializedName("name")
    private String name;
    @SerializedName("id")
    private String id;
    @SerializedName("groupId")
    private String groupId;
    @SerializedName("topic")
    private String topic;

    public Endpoint(String name, String id, String groupId, String topic) {
        this.name = name;
        this.id = id;
        this.groupId = groupId;
        this.topic = topic;
    }

    public Endpoint(Parcel in) {
        this.name = in.readString();
        this.id = in.readString();
        this.groupId = in.readString();
        this.topic = in.readString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(id);
        dest.writeString(groupId);
        dest.writeString(topic);
    }
}




