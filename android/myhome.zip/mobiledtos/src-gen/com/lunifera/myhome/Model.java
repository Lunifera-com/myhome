package com.lunifera.myhome;

import com.lunifera.myhome.Endpoint;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import javax.validation.Valid;
import org.lunifera.dsl.common.datatypes.IDto;
import org.lunifera.dsl.dto.lib.MappingContext;
import org.lunifera.runtime.common.annotations.Dispose;
import org.lunifera.runtime.common.annotations.DomainReference;

@SuppressWarnings("all")
public class Model implements IDto, Serializable, PropertyChangeListener {
  private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
  
  @Dispose
  private boolean disposed;
  
  private String id;
  
  private String name;
  
  @DomainReference
  @Valid
  private List<Endpoint> endpoints;
  
  /**
   * Returns true, if the object is disposed. 
   * Disposed means, that it is prepared for garbage collection and may not be used anymore. 
   * Accessing objects that are already disposed will cause runtime exceptions.
   */
  public boolean isDisposed() {
    return this.disposed;
  }
  
  /**
   * @see PropertyChangeSupport#addPropertyChangeListener(PropertyChangeListener)
   */
  public void addPropertyChangeListener(final PropertyChangeListener listener) {
    propertyChangeSupport.addPropertyChangeListener(listener);
  }
  
  /**
   * @see PropertyChangeSupport#addPropertyChangeListener(String, PropertyChangeListener)
   */
  public void addPropertyChangeListener(final String propertyName, final PropertyChangeListener listener) {
    propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
  }
  
  /**
   * @see PropertyChangeSupport#removePropertyChangeListener(PropertyChangeListener)
   */
  public void removePropertyChangeListener(final PropertyChangeListener listener) {
    propertyChangeSupport.removePropertyChangeListener(listener);
  }
  
  /**
   * @see PropertyChangeSupport#removePropertyChangeListener(String, PropertyChangeListener)
   */
  public void removePropertyChangeListener(final String propertyName, final PropertyChangeListener listener) {
    propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
  }
  
  /**
   * @see PropertyChangeSupport#firePropertyChange(String, Object, Object)
   */
  public void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) {
    propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
  }
  
  /**
   * Checks whether the object is disposed.
   * @throws RuntimeException if the object is disposed.
   */
  private void checkDisposed() {
    if (isDisposed()) {
      throw new RuntimeException("Object already disposed: " + this);
    }
  }
  
  /**
   * Calling dispose will destroy that instance. The internal state will be 
   * set to 'disposed' and methods of that object must not be used anymore. 
   * Each call will result in runtime exceptions.<br/>
   * If this object keeps composition containments, these will be disposed too. 
   * So the whole composition containment tree will be disposed on calling this method.
   */
  @Dispose
  public void dispose() {
    if (isDisposed()) {
      return;
    }
    try {
      // Dispose all the composition references.
      if (this.endpoints != null) {
        for (Endpoint endpoint : this.endpoints) {
          endpoint.dispose();
        }
        this.endpoints = null;
      }
      
    }
    finally {
      firePropertyChange("disposed", this.disposed, this.disposed = true);
    }
    
  }
  
  /**
   * Returns the id property or <code>null</code> if not present.
   */
  public String getId() {
    return this.id;
  }
  
  /**
   * Sets the <code>id</code> property to this instance.
   * 
   * @param id - the property
   * @throws RuntimeException if instance is <code>disposed</code>
   * 
   */
  public void setId(final String id) {
    firePropertyChange("id", this.id, this.id = id );
  }
  
  /**
   * Returns the name property or <code>null</code> if not present.
   */
  public String getName() {
    return this.name;
  }
  
  /**
   * Sets the <code>name</code> property to this instance.
   * 
   * @param name - the property
   * @throws RuntimeException if instance is <code>disposed</code>
   * 
   */
  public void setName(final String name) {
    firePropertyChange("name", this.name, this.name = name );
  }
  
  /**
   * Returns an unmodifiable list of endpoints.
   */
  public List<Endpoint> getEndpoints() {
    return Collections.unmodifiableList(internalGetEndpoints());
  }
  
  /**
   * Returns the list of <code>Endpoint</code>s thereby lazy initializing it. For internal use only!
   * 
   * @return list - the resulting list
   * 
   */
  private List<Endpoint> internalGetEndpoints() {
    if (this.endpoints == null) {
      this.endpoints = new java.util.ArrayList<Endpoint>();
    }
    return this.endpoints;
  }
  
  /**
   * Adds the given endpoint to this object. <p>
   * Since the reference is a composition reference, the opposite reference <code>Endpoint#model</code> of the <code>endpoint</code> will be handled automatically and no further coding is required to keep them in sync.<p>
   * See {@link Endpoint#setModel(Endpoint)}.
   * 
   * @param endpoint - the property
   * @throws RuntimeException if instance is <code>disposed</code>
   * 
   */
  public void addToEndpoints(final Endpoint endpoint) {
    checkDisposed();
    
    endpoint.setModel(this);
  }
  
  /**
   * Removes the given endpoint from this object. <p>
   * Since the reference is a cascading reference, the opposite reference (Endpoint.model)
   * of the endpoint will be handled automatically and no further coding is required to keep them in sync. 
   * See {@link Endpoint#setModel(Endpoint)}.
   * 
   * @param endpoint - the property
   * @throws RuntimeException if instance is <code>disposed</code>
   * 
   */
  public void removeFromEndpoints(final Endpoint endpoint) {
    checkDisposed();
    
    endpoint.setModel(null);
  }
  
  /**
   * For internal use only!
   */
  void internalAddToEndpoints(final Endpoint endpoint) {
    internalGetEndpoints().add(endpoint);
  }
  
  /**
   * For internal use only!
   */
  void internalRemoveFromEndpoints(final Endpoint endpoint) {
    internalGetEndpoints().remove(endpoint);
  }
  
  /**
   * Sets the <code>endpoints</code> property to this instance.
   * Since the reference has an opposite reference, the opposite <code>Endpoint#
   * model</code> of the <code>endpoints</code> will be handled automatically and no 
   * further coding is required to keep them in sync.<p>
   * See {@link Endpoint#setModel(Endpoint)
   * 
   * @param endpoints - the property
   * @throws RuntimeException if instance is <code>disposed</code>
   * 
   */
  public void setEndpoints(final List<Endpoint> endpoints) {
    checkDisposed();
    for (Endpoint dto : internalGetEndpoints().toArray(new Endpoint[this.endpoints.size()])) {
    	removeFromEndpoints(dto);
    }
    
    if(endpoints == null) {
    	return;
    }
    
    for (Endpoint dto : endpoints) {
    	addToEndpoints(dto);
    }
  }
  
  public Model createDto() {
    return new Model();
  }
  
  public Model copy(final MappingContext context) {
    checkDisposed();
    
    if (context == null) {
    	throw new IllegalArgumentException("Context must not be null!");
    }
    
    if(context.isMaxLevel()){
    	return null;
    }
    
    // if context contains a copied instance of this object
    // then return it
    Model newDto = context.get(this);
    if(newDto != null){
    	return newDto;
    }
    
    try{
    	context.increaseLevel();
    	
    	newDto = createDto();
    	context.register(this, newDto);
    	
    	// first copy the containments and attributes
    	copyContainments(this, newDto, context);
    	
    	// then copy cross references to ensure proper
    	// opposite references are copied too.
    	copyCrossReferences(this, newDto, context);
    } finally {
    	context.decreaseLevel();
    }
    
    return newDto;
  }
  
  public void copyContainments(final Model dto, final Model newDto, final MappingContext context) {
    checkDisposed();
    
    if (context == null) {
    	throw new IllegalArgumentException("Context must not be null!");
    }
    
    
    // copy attributes and beans (beans if derived from entity model)
    // copy id
    newDto.setId(getId());
    // copy name
    newDto.setName(getName());
    
    // copy containment references (cascading is true)
    // copy list of endpoints dtos
    for(com.lunifera.myhome.Endpoint _dto : getEndpoints()) {
    	newDto.addToEndpoints(_dto.copy(context));
    }
  }
  
  public void copyCrossReferences(final Model dto, final Model newDto, final org.lunifera.dsl.dto.lib.MappingContext context) {
    checkDisposed();
    
    if (context == null) {
    	throw new IllegalArgumentException("Context must not be null!");
    }
    
    
    // copy cross references (cascading is false)
  }
  
  public void propertyChange(final java.beans.PropertyChangeEvent event) {
    Object source = event.getSource();
    
    // forward the event from embeddable beans to all listeners. So the parent of the embeddable
    // bean will become notified and its dirty state can be handled properly
    { 
    	// no super class available to forward event
    }
  }
}
